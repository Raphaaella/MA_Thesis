# 2018_master_thesis
Master Thesis 'A Robustness Metric for Relational Query Execution Plans'
